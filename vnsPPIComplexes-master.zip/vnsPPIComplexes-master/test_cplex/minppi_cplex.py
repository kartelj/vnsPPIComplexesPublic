#!/usr/bin/python
# ILP model iz Nakajima 2018
import cplex
from cplex.exceptions import CplexError
import sys
import datetime
from numpy import * 

class General:
	def __init__(self,st,argv):
		self.st=st
		self.et=-1
		self.argv=argv
		self.tf='%Y-%m-%d %H:%M:%S'

class Problem:
	def __init__(self,nc):		
		self.nc=nc
		
def main():		
	if len(sys.argv)<2:
		print 'Ulazni format je: minppi_cplex.py ime_instance'
		sys.exit(0)
	sys.argv[1]=sys.argv[1].lower()
	general=General(datetime.datetime.now(),sys.argv)
	with open(sys.argv[1]+'.complexes') as f:
		[nc] = [int(x) for x in f.readline().split()]
		problem=Problem(nc)
		problem.complex = []
		for line in f:
			complexVertices = [int(x) for x in line.split()]
			problem.complex.append(complexVertices)

	with open(sys.argv[1]+'.edges') as f:
		[nv,_] = [int(x) for x in f.readline().split()]
		problem.nv=nv
	
	try:
		cpl_prob = cplex.Cplex()
		cpl_prob.parameters.timelimit.set(10800.0)
		#cpl_prob.parameters.threads.set(1)
		cpl_prob.objective.set_sense(cpl_prob.objective.sense.minimize)
		# dodajemo promenljive i njihove lb i ub
		myexprs = []
		myrhs=[]
		mysenses=[]
		mynames=[]
		# za svaki kompleks
		consCnt = 0
		varSet = set([])
		for c in range(problem.nc):
			Tp = int(ceil(log2(len(problem.complex[c]))))
			# dodajemo prvi skup ogranicenja
			for i in problem.complex[c]:
				for j in problem.complex[c]:
					if i==j:
						continue
					varName1 = 'x_'+str(i)+'_'+str(j)+'_'+str(Tp)
					varSet.add(varName1)
					myexprs.append([[varName1],[1.0]])
					myrhs.append(1.0)
					mysenses.append('E')
					mynames.append('cons1_'+str(consCnt))
					consCnt+=1
			# drugi skup
			for i in problem.complex[c]:
				for j in problem.complex[c]:
					if i==j:
						continue
					varName1 = 'x_'+str(i)+'_'+str(j)+'_0'
					# da ne bi pravili novu promenljivu
					if i>j:
						varName2 = 'e_'+str(j)+'_'+str(i)
					else:
						varName2 = 'e_'+str(i)+'_'+str(j)
					varSet.add(varName1)
					varSet.add(varName2)
					myexprs.append([[varName1,varName2],[1.0,-1.0]])
					myrhs.append(0.0)
					mysenses.append('L')
					mynames.append('cons2_'+str(consCnt))
					consCnt+=1
			# treci skup
			for t in range(Tp):
				for i in problem.complex[c]:
					for j in problem.complex[c]:
						if i==j:
							continue
						varName1 = 'x_'+str(i)+'_'+str(j)+'_'+str(t+1)
						varName2 = 'x_'+str(i)+'_'+str(j)+'_'+str(t)
						varNames = [varName1,varName2]
						varCoef = [1.0,-1.0]
						varSet.add(varName1)
						varSet.add(varName2)
						for k in problem.complex[c]:
							if k == i or k==j:
								continue
							varName1 = 'x_'+str(i)+'_'+str(j)+'_'+str(k)+'_'+str(t+1)
							varNames.append(varName1)
							varCoef.append(-1.0)
							varSet.add(varName1)
						myexprs.append([varNames,varCoef])
						myrhs.append(0.0)
						mysenses.append('L')
						mynames.append('cons3_'+str(consCnt))
						consCnt+=1

			# cetvrti skup
			for t in range(Tp):
				for i in problem.complex[c]:
					for j in problem.complex[c]:
						if i==j:
							continue
						for k in problem.complex[c]:
							if k == i or k==j:
								continue
							varNames = ['x_'+str(i)+'_'+str(j)+'_'+str(k)+'_'+str(t+1),
								'x_'+str(i)+'_'+str(k)+'_'+str(t), 
								'x_'+str(k)+'_'+str(j)+'_'+str(t)]
							varCoef=[1.0,-0.5,-0.5]
							for varName in varNames:
								varSet.add(varName)
							myexprs.append([varNames,varCoef])
							myrhs.append(0.0)
							mysenses.append('L')
							mynames.append('cons4_'+str(consCnt))
							consCnt+=1
			
		objCoef = []
		varNames = []
		for var in varSet:
			if var.startswith('e'):
				objCoef.append(1.0)
			else:
				objCoef.append(0.0)
			varNames.append(var)

		#print 'Ogranicenja'
		#for i in range(len(myexprs)):
		#	print mynames[i], myexprs[i],mysenses[i],myrhs[i]

		problem.objCoef=objCoef
		problem.varNames=varNames
		cpl_prob.variables.add(obj = objCoef, lb = [0.0]*len(varSet), ub = [1.0]*len(varSet), types = 'B'*len(varSet),names = varNames)
		cpl_prob.linear_constraints.add(lin_expr = myexprs,senses=mysenses,rhs = myrhs, names = mynames)
		print 'Model ima ',len(varSet),'promenljivih i',consCnt,'ogranicenja'
		cpl_prob.solve()
		general.et=datetime.datetime.now()
		printresults(cpl_prob, general,problem)
	except CplexError, exc:
		print exc
		return
		
#def printmodel(model):
#	print 'Constraints:'
#	for i in range(r):
#		print model.my_rownames[i]," + ".join(['('+str(model.my_rows[i][1][x])+')'+str(model.my_rows[i][0][x]) for x in range(len(model.my_rows[i][0]))]),model.my_senses[i]+str(model.my_rhs[i])
	
def printresults(cpl_prob, general,problem):
	fout=open('./results.txt', 'a+')
	numcols = cpl_prob.variables.get_num()
	numrows = cpl_prob.linear_constraints.get_num()
	slack = cpl_prob.solution.get_linear_slacks()
	x     = cpl_prob.solution.get_values()
	testsum=0
	for j in range(numcols):
		if problem.varNames[j].startswith('e') and x[j]==1:
			print '%s: Name=%s  Value = %1f  Coef = %1f' % (j,problem.varNames[j], x[j],problem.objCoef[j])
    # solution.get_status() returns an integer code
	print 'Solution status = ' , cpl_prob.solution.get_status(), ':',
    # the following line prints the corresponding string
	print cpl_prob.solution.status[cpl_prob.solution.get_status()]
	print 'Solution value  = ', cpl_prob.solution.get_objective_value()
	print >> fout, '\n\nPoziv\t\t\t'," ".join(general.argv[1:])
	print >> fout, 'Funkcija cilja\t', cpl_prob.solution.get_objective_value()
	print >> fout,'Status\t\t\t',cpl_prob.solution.status[cpl_prob.solution.get_status()]
	print >> fout,'Zapoceto\t\t',general.st, '\nZavrseno\t\t',general.et,'\nTrajanje\t\t',general.et-general.st

main()