1. exe folder contains executable for vns and greedy algorithm.
2. instance_generator folder contains executable for creation of random instances. 
3. instances and new_instances contains some instances used in the research. 
Full set of instances can be found inside rar files available on the https://github.com/kartelj/vnsPPIComplexesPublic
4. test_cplex, test_greedy and test_vns folders contains examples of executable usage.
5. test_vns_shaking_fixGreedy_effect contains algorithm calls for solution structural analysis before shaking and after fixGreedy procedures. 

